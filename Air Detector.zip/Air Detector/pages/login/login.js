// pages/login/index.js
import Toast from '../../@vant/weapp/toast/toast';
Page({

  data: {
    isLogin: true,
    inputUserName: "",
    inputPassWord: "",
    inputContect: "",
    showFindPW: false,
    showResetPW: false
  },

 
  onClick: function (event) {
    var that = this;
    Toast.loading({
      duration: 0, 
      forbidClick: true, 
      message: that.data.isLogin ? "Log in..." : "sign in..."
    });

    setTimeout(() => {
      if (!that.data.isLogin) {
        wx.setStorage({
          key: "user",
          data: {
            username: that.data.inputUserName,
            password: that.data.inputPassWord,
            contect: that.data.inputContect
          },
          success(res) {
            console.log(res);
            console.log("Sign in successful!");
            Toast.success("Sign in successful");
          },
          fail(res) {
            console.log(res);
            console.log("Sign in failed！");
            Toast.success("Sign in failed");
          }
        });
      } else {
        wx.getStorage({
          key: "user",
          success(res) {
            console.log(res.data);
            if (
              that.data.inputUserName === res.data.username &&
              that.data.inputPassWord === res.data.password
            ) {
              Toast.success("log in successful");
              //500ms
              setTimeout(() => {
                wx.switchTab({
                  url: "/pages/index/index"
                });
              }, 500);
            } else {
              Toast.fail("user or ps incorrect");
            }
          },
          fail(res) {
            console.log(res);
            Toast.fail("This user is not available in the database");
          }
        });
      }
    }, 1000);
  },

  
  onOptionClick: function (event) {
    this.setData({
      isLogin: !this.data.isLogin
    });
    console.log(
      `The toggle sign in / log in button has been clicked! Currently in${
        this.data.isLogin ? "log in" : "sign in"
      }！`
    );
  },

 
  onForgetClick: function (event) {
    this.setData({
      showFindPW: true
    });
  },

 
  onFindPWConfirm: function (event) {
    var that = this;
    wx.getStorage({
      key: "user",
      success(res) {
        console.log(res.data);
        if (that.data.inputContect === res.data.contect) {
          that.setData({
            showResetPW: true,
            inputUserName: res.data.username
          })
          console.log("Find user：", res.data.username);
        } else {
          Toast.fail("No information about this user");
          that.data.inputContect = "";
        }
      },
      fail(res) {
        console.log(res);
        Toast.fail("This user is not available in the database");
        that.data.inputContect = "";
      }
    });
  },

  
  onFindPWCancel: function (event) {
    this.setData({
      showFindPW: false,
      inputContect: ""
    });
  },

  
  onResetPWConfirm: function (event) {
    var that = this;
    wx.setStorage({
      key: "user",
      data: {
        username: that.inputUserName,
        password: that.inputPassWord,
        contect: that.inputContect
      },
      success(res) {
        console.log(res);
        console.log("Password reset successful！");
        Toast.success("Password reset successful");
      },
      fail(res) {
        console.log(res);
        console.log("Password reset failed！");
        Toast.success("Password reset failed");
      }
    });
  },

  onResetPWCancel: function (event) {
    this.setData({
      showResetPW: false,
      inputUserName: "",
      inputPassWord: "",
      inputContect: ""
    });
  }
})