// index.js
const { connect } = require("../../utils/mqtt4/mqtt");

const mqttHost = "110.40.167.13"; 
const mqttPort = 8084; 

const deviceSubTopic = "/myairdetector/sub"; 
const devicePubTopic = "/myairdetector/pub"; 

const mpSubTopic = devicePubTopic;
const mpPubTopic = deviceSubTopic;

const mqttUrl = `wxs://${mqttHost}:${mqttPort}/mqtt`; // mqtt

Page({
  data: {
    client: {},
    AC_H: false,
    AC_C: false,
    Humidifier: false,
    Alarm: false,
    mqtt: true,
  },
  onAC_HChange(event) {
    var that = this;
    console.log(event.detail);
    let sw = event.detail.value;
    that.setData({
      AC_H: sw
    })
    if (sw) {
      that.data.client.publish(mpPubTopic, '{"target":"AC_H","value":1}', function (err) {
        if (!err) {
          console.log("Successfully given the order - turn on the AC_H");
        }
      });
    } else {
      that.data.client.publish(mpPubTopic, '{"target":"AC_H","value":0}', function (err) {
        if (!err) {
          console.log("Successfully given the order - turn off the AC_H");
        }
      });
    }
  },
  onAC_CChange(event) {
    var that = this;
    console.log(event.detail);
    let sw = event.detail.value;
    that.setData({
      AC_C: sw
    })
    if (sw) {
      that.data.client.publish(mpPubTopic, '{"target":"AC_C","value":1}', function (err) {
        if (!err) {
          console.log("Successfully given the order - turn on the AC_C");
        }
      });
    } else {
      that.data.client.publish(mpPubTopic, '{"target":"AC_C","value":0}', function (err) {
        if (!err) {
          console.log("Successfully given the order - turn off the AC_C");
        }
      });
    }
  },
  onHumidifierChange(event) {
    var that = this;
    console.log(event.detail);
    let sw = event.detail.value;
    that.setData({
      Humidifier: sw
    })
    if (sw) {
      that.data.client.publish(mpPubTopic, '{"target":"Humidifier","value":1}', function (err) {
        if (!err) {
          console.log("Successfully given the order - turn on the Humidifier");
        }
      });
    } else {
      that.data.client.publish(mpPubTopic, '{"target":"Humidifier","value":0}', function (err) {
        if (!err) {
          console.log("Successfully given the order - turn off the Humidifier");
        }
      });
    }
  },
  onAlarmChange(event) {
    var that = this;
    console.log(event.detail);
    let sw = event.detail.value;
    that.setData({
      Alarm: sw
    })
    if (sw) {
      that.data.client.publish(mpPubTopic, '{"target":"Alarm","value":1}', function (err) {
        if (!err) {
          console.log("Successfully given the order - turn on the Alarm");
        }
      });
    } else {
      that.data.client.publish(mpPubTopic, '{"target":"Alarm","value":0}', function (err) {
        if (!err) {
          console.log("Successfully given the order - turn off the Alarm");
        }
      });
    }
  },
  onmqttChange(event) {
    var that = this;
    console.log(event.detail);
    let sw = event.detail.value;
    that.setData({
      mqtt: sw
    })
  },
  onShow() {
    var that = this;
    that.setData({
      client: connect(mqttUrl)
    })
    that.data.client.on("message", function (topic, message) {
      console.log(topic);
      // message is a stream of Buffer bytes in hexadecimal
      let dataFromDev = {};
      // Attempted JSON parsing
      try {
        dataFromDev = JSON.parse(message);
        console.log(dataFromDev);
        that.setData({
          AC_H: dataFromDev.AC_H,
          AC_C: dataFromDev.AC_C,
          Humidifier: dataFromDev.Humidifier,
          Alarm: dataFromDev.Alarm,
        })
      } catch (error) {
        // Parsing failure errors are captured and printed ( the program will not be affected after the error is captured)
        console.log(error);
      }
    })
  }
})