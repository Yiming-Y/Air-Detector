// index.js
const { connect } = require("../../utils/mqtt4/mqtt");

const hefengKey = "d90f2e08db4c4961aec780913a364be1"; 

const mqttHost = "110.40.167.13"; //mqtt
const mqttPort = 8084; //mqtt/IP

const hefengVIP = false; 

const deviceSubTopic = "/myairdetector/sub"; 
const devicePubTopic = "/myairdetector/pub"; 

const mpSubTopic = devicePubTopic;
const mpPubTopic = deviceSubTopic;

const mqttUrl = `wxs://${mqttHost}:${mqttPort}/mqtt`; //  mqtt

const hefengApi = "https://api.qweather.com/v7"; 
const hefengFreeApi = "https://devapi.qweather.com/v7";

const hefengWeather = `${hefengVIP ? hefengApi : hefengFreeApi}/weather/now?`; 
const hefengAir = `${hefengVIP ? hefengApi : hefengFreeApi}/air/now?`; 

const geoApi = "https://geoapi.qweather.com/v2/city/lookup?" 

Page({
  data: {
    client: {},
    Tem: 0,
    Hum: 0,
    Light: 0,
    PM25: 0,
    AQ: 0,
    Gas: 0,
    Smoke:0,
    CO: 0,
    BMP: 0,
    High: 0,
    area: "Requesting", 
    city: "Requesting", 
    airValue: 0, 
    weather: "Requesting", 
    weatherAdvice: "Good weather", 
  },

  onShow() {
    var that = this;
    wx.showToast({
      title: "Connecting to the server....",
      icon: "loading",
      duration: 10000,
      mask: true,
    });
    let second = 10;
    var toastTimer = setInterval(() => {
      second--;
      if (second) {
        wx.showToast({
          title: `Connecting to the server...${second}`,
          icon: "loading",
          duration: 1000,
          mask: true,
        });
      } else {
        clearInterval(toastTimer);
        wx.showToast({
          title: "Connection failed",
          icon: "error",
          mask: true,
        });
      }
    }, 1000);
    that.setData({
      client: connect(mqttUrl)
    })

    that.data.client.on("connect", function () {
      console.log("Successful connection to mqtt server！");
      clearInterval(toastTimer);
      wx.showToast({
        title: "Connection successful",
        icon: "success",
        mask: true,
      });
      // Subscribe to the topic in one second
      setTimeout(() => {
        that.data.client.subscribe(mpSubTopic, function (err) {
          if (!err) {
            console.log("Successfully subscribed to device uplink data!");
            wx.showToast({
              title: "Successfully subscribed",
              icon: "success",
              mask: true,
            });
          }
        });
      }, 1000);
    });
    that.data.client.on("message", function (topic, message) {
      console.log(topic);
      // message is a stream of Buffer bytes in hexadecimal
      let dataFromDev = {};
      // Attempted JSON parsing
      try {
        dataFromDev = JSON.parse(message);
        console.log(dataFromDev);
        that.setData({
          Tem: dataFromDev.Tem,
          Hum: dataFromDev.Hum,
          Light: dataFromDev.Light,
          PM25:dataFromDev.PM25,
          AQ: dataFromDev.AQ,
          Gas: dataFromDev.Gas,
          smoke:dataFromDev.smoke,
          CO: dataFromDev.CO,
          BMP: dataFromDev.BMP,
          High: dataFromDev.High,
        })
      } catch (error) {
        // Parsing failure errors are captured and printed (they do not affect the continuation of the program after they have been captured)
        console.log(error);
      }
    })

    // Get weather data
    wx.getFuzzyLocation({
      type: "wgs84",
      success(res) {
        const latitude = res.latitude;
        const longitude = res.longitude;
        const key = hefengKey;
        wx.request({
          url: `${geoApi}location=${longitude},${latitude}&key=${key}&lang=en`, //get location
          success(res) {
            console.log(res.data);
            if (res.data.code == "401") {
              console.error("HUAQING --- Please check if your Weather API or Key is correct！");
              return;
            }
            try {
              const {
                location
              } = res.data;
              that.setData({
                area: location[0].name, //town
                city: location[0].adm2 //city
              })
            } catch (error) {
              console.error(error);
            }
          },
        });
        wx.request({
          url: `${hefengWeather}location=${longitude},${latitude}&key=${key}&lang=en`, //get real-time weather data
          success(res) {
            console.log(res.data);
            if (res.data.code == "401") {
              console.error("Please check if your Weather API or Key is correct！");
              return;
            }
            try {
              const {
                now
              } = res.data;
              that.setData({
                weather: now.text, // weather
                airValue: now.feelsLike//Air Index
              })
            } catch (error) {
              console.error(error);
            }
          },
        });
      },
    });
  }
})