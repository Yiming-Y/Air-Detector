// app.js
App({
  onLaunch() {
    // Local storage capacity
    const logs = wx.getStorageSync('logs') || []
    logs.unshift(Date.now())
    wx.setStorageSync('logs', logs)

    // Login
    wx.login({
      success: res => {
        // Send res.code to the backend to retrieve openId, sessionKey, unionId
      }
    })
  },
  globalData: {
    userInfo: null
  }
})
